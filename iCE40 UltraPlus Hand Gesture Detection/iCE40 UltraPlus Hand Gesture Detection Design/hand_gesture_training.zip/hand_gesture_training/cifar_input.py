# Copyright 2016 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

"""CIFAR dataset input module.
"""

import tensorflow as tf
import random as rn


# import cv2

def build_input(dataset, data_path, batch_size, mode, gray, classes):
    """Build CIFAR image and labels.

    Args:
      dataset: signlang.
      data_path: Filename for data.
      batch_size: Input batch size.
      mode: Either 'train' or 'eval'.
    Returns:
      images: Batches of images. [batch_size, image_size, image_size, channels]
      labels: Batches of labels. [batch_size, num_classes]
    Raises:
      ValueError: when the specified dataset is not supported.
    """
    image_size = 32  # target image size
    if dataset == 'signlang':
        num_classes = classes
    else:
        raise ValueError('Not supported dataset %s', dataset)
    depth = 3

    data_files = tf.gfile.Glob(data_path)
    file_queue = tf.train.string_input_producer(data_files, shuffle=True)

    if dataset == 'signlang':  # TFRecord format
        reader = tf.TFRecordReader()
        _, serialized_example = reader.read(file_queue)
        features = tf.parse_single_example(
            serialized_example,
            features={
                'image/height': tf.FixedLenFeature([], tf.int64),
                'image/width': tf.FixedLenFeature([], tf.int64),
                'image/class/label': tf.FixedLenFeature([], tf.int64),
                'image/encoded': tf.FixedLenFeature([], tf.string)
            }
        )
        image = tf.image.decode_jpeg(features['image/encoded'], channels=3)
        assert len(image.shape) == 3
        label = tf.cast(features['image/class/label'], tf.int32)
        label = tf.reshape(label, [1])
        image = tf.cast(image, tf.float32)

    if mode == 'train' or mode == 'freeze':
        if dataset == 'signlang':
            if False:
                radian = tf.random_uniform([1], minval=0,
                                           maxval=360.0 * 3.14159265 / 180.0)  # free rotation with large image
                image = tf.contrib.image.rotate(image, radian, interpolation='BILINEAR')
                image = tf.image.resize_image_with_crop_or_pad(image, image_size + 4, image_size + 4)  # center crop
        else:
            image = tf.image.resize_image_with_crop_or_pad(image, image_size + 4, image_size + 4)

        if False:  # 90,180,270 rotation
            angle_choice = tf.random_uniform([], minval=0, maxval=399, dtype=tf.int32)  # []=0th rank; 0~399
            image = tf.cond(angle_choice > 99, lambda: tf.image.rot90(image, angle_choice / 100), lambda: image)

        # rotate from -degree to +degree
        # first rotate -degree by rotating 360-degree and then randomly rotate up to 2*degree
        degree = 20.0
        radian = (360.0 - degree) * 3.14159265 / 180.0
        image = tf.contrib.image.rotate(image, radian, interpolation='BILINEAR')

        degree *= 2.0
        radian = tf.random_uniform([1], minval=0.0, maxval=degree * 3.14159265 / 180.0,
                                   dtype=tf.float32)  # free rotation with large image
        image = tf.contrib.image.rotate(image, radian, interpolation='BILINEAR')

        if False:  # no flip for directional dataset
            image = tf.image.random_flip_left_right(image)

        const_val = 0.0
        padding_amt = 2  # org_x // 7 # 10% paddig
        paddedR = tf.pad(tensor=image[:, :, 0:1],  # the R channel of tensor
                         paddings=[[padding_amt, padding_amt], [padding_amt, padding_amt], [0, 0]],
                         # don't pad it in batch or channel dimensions
                         mode='Constant',
                         name='padAverageRed',
                         constant_values=const_val)
        paddedG = tf.pad(tensor=image[:, :, 1:2],  # the G channel of tensor
                         paddings=[[padding_amt, padding_amt], [padding_amt, padding_amt], [0, 0]],
                         # don't pad it in batch or channel dimensions
                         mode='Constant',
                         name='padAverageGreen',
                         constant_values=const_val)
        paddedB = tf.pad(tensor=image[:, :, 2:3],  # the B channel of tensor
                         paddings=[[padding_amt, padding_amt], [padding_amt, padding_amt], [0, 0]],
                         # don't pad it in batch or channel dimensions
                         mode='Constant',
                         name='padAverageBlue',
                         constant_values=const_val)
        image = tf.concat([paddedR, paddedG, paddedB], 2)
        image = tf.random_crop(image, [image_size, image_size, 3])  # 90% size crop

        if gray:  # Gray color
            image = tf.image.rgb_to_grayscale(image)  # Gray color
            depth = 1

        # tf.image.decode_image returns RGB format, while we want to train w/ BGR (for FPGA HW). So, we convert the order
        channels = tf.unstack(image, axis=-1)

        if gray:
            image = tf.stack([channels[0]], axis=-1)
        else:
            # RGB to BGR Conversion
            image = tf.stack([channels[2], channels[1], channels[0]], axis=-1)

        image /= 128.0  # [0, 2)

        example_queue = tf.RandomShuffleQueue(
            capacity=16 * batch_size,
            min_after_dequeue=8 * batch_size,
            dtypes=[tf.float32, tf.int32],
            shapes=[[image_size, image_size, depth], [1]])
        num_threads = 16
    else:  # evaluation
        if dataset == 'signlang':
            if False:
                image = tf.image.resize_images(image, [image_size, image_size])
        else:
            image = tf.image.resize_image_with_crop_or_pad(image, image_size, image_size)

        if gray:  # Gray color
            image = tf.image.rgb_to_grayscale(image)  # Gray color
            depth = 1

        # tf.image.decode_image returns RGB format, while we want to train w/ BGR (for FPGA HW). So, we convert the order
        channels = tf.unstack(image, axis=-1)
        if gray:
            image = tf.stack([channels[0]], axis=-1)
        else:
            # RGB to BGR conversion
            image = tf.stack([channels[2], channels[1], channels[0]], axis=-1)

        image /= 128.0

        example_queue = tf.FIFOQueue(
            3 * batch_size,
            dtypes=[tf.float32, tf.int32],
            shapes=[[image_size, image_size, depth], [1]])
        num_threads = 1

    example_enqueue_op = example_queue.enqueue([image, label])
    tf.train.add_queue_runner(tf.train.queue_runner.QueueRunner(
        example_queue, [example_enqueue_op] * num_threads))

    # Read 'batch' labels + images from the example queue.
    images, labels = example_queue.dequeue_many(batch_size)
    labels = tf.reshape(labels, [batch_size, 1])
    indices = tf.reshape(tf.range(0, batch_size, 1), [batch_size, 1])
    labels = tf.sparse_to_dense(
        tf.concat(values=[indices, labels], axis=1),
        [batch_size, num_classes], 1.0, 0.0)

    assert len(images.get_shape()) == 4
    assert images.get_shape()[0] == batch_size
    assert images.get_shape()[-1] == depth
    assert len(labels.get_shape()) == 2
    assert labels.get_shape()[0] == batch_size
    assert labels.get_shape()[1] == num_classes

    # Display the training images in the visualizer.
    channels = tf.unstack(images, axis=-1)  # images=BGR, images_viz=RGB
    if gray:
        images_viz = tf.stack([channels[0]], axis=-1)
    else:
        images_viz = tf.stack([channels[2], channels[1], channels[0]], axis=-1)

    tf.summary.image('images', images_viz)
    return images, labels
