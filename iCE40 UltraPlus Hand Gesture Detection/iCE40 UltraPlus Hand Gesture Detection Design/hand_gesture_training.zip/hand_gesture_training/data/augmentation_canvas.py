import cv2
import numpy as np
from math import ceil, sqrt
import os
import argparse
import shutil
from PIL import Image


def gen_canvas_img(img, img_w_o, img_h_o, dest_path, filename, shift, zoom):
    img_h, img_w, ch = img.shape
    for aug in ['br-', 'tl-', 'tr-', 'bl-']:
        for move_h in range(5, 11, 5):
            move_pixels_h = ceil(img_h * move_h / 100)
            for move_w in range(5, 11, 5):
                filename_move = aug + str(move_h) + "-" + str(move_w) + "-" + filename
                move_pixels_w = ceil(img_w * move_w / 100)
                temp_image = np.zeros((img_h, img_w, ch), np.uint8)
                if aug == 'br-':
                    temp_image[move_pixels_h:img_h_o, move_pixels_w:img_w_o] = img[0:img_h_o - move_pixels_h,
                                                                               0:img_w_o - move_pixels_w]
                elif aug == 'tl-':
                    temp_image[0:img_h_o - move_pixels_h, 0:img_w_o - move_pixels_w] = img[move_pixels_h:img_h_o,
                                                                                       move_pixels_w:img_w_o]
                elif aug == 'tr-':
                    temp_image[0:img_h_o - move_pixels_h, move_pixels_w:img_w_o] = img[move_pixels_h:img_h_o,
                                                                                   0:img_w_o - move_pixels_w]
                elif aug == 'bl-':
                    temp_image[move_pixels_h:img_h_o, 0:img_w_o - move_pixels_w] = img[0:img_h_o - move_pixels_h,
                                                                                   move_pixels_w:img_w_o]
                cv2.imwrite(os.path.join(dest_path, filename_move), cv2.resize(temp_image, (img_h_o, img_w_o)))
                for ratio in range(zoom, 30, 10):
                    i = 0
                    dst_h = dst_w = ceil((max(img_h, img_w) * (100 + ratio)) / 100)
                    for off_h in range(0, dst_h - img_h, shift):
                        for off_w in range(0, dst_w - img_w, shift):
                            filename_tmp = str(i) + "-" + str(ratio) + "-" + filename_move
                            i += 1
                            dst = np.zeros((dst_h, dst_w, ch), np.uint8)
                            dst[off_h: off_h + img_h, off_w: off_w + img_w] = temp_image
                            dst = cv2.resize(dst, (img_h_o, img_w_o))
                            cv2.imwrite(os.path.join(dest_path, filename_tmp), dst)

def rotate_img(image, img_w_o, img_h_o, dest_path, filename):
    for angle in range(21, 360, 20):
        image_height = image.shape[0]
        image_width = image.shape[1]
        diagonal_square = (image_width*image_width) + (
            image_height* image_height
        )
        #
        diagonal = round(sqrt(diagonal_square))
        padding_top = round((diagonal-image_height) / 2)
        padding_bottom = round((diagonal-image_height) / 2)
        padding_right = round((diagonal-image_width) / 2)
        padding_left = round((diagonal-image_width) / 2)
        padded_image = cv2.copyMakeBorder(image,
                                          top=padding_top,
                                          bottom=padding_bottom,
                                          left=padding_left,
                                          right=padding_right,
                                          borderType=cv2.BORDER_CONSTANT,
                                          value=0
                )
        padded_height = padded_image.shape[0]
        padded_width = padded_image.shape[1]
        transform_matrix = cv2.getRotationMatrix2D(
                    (padded_height/2,
                     padded_width/2), # center
                    angle, # angle
          1.0) # scale
        rotated_image = cv2.warpAffine(padded_image,
                                       transform_matrix,
                                       (diagonal, diagonal),
                                       flags=cv2.INTER_LANCZOS4)
        filename_rotate = "rotate_"+str(angle)+filename
        cv2.imwrite(os.path.join(dest_path, filename_rotate), cv2.resize(rotated_image, (img_w_o, img_h_o)))


def main(args):
    if not os.path.isdir(args.output_dir):
        os.mkdir(args.output_dir)

    if args.input_dir[-1] == '/':
        args.input_dir = args.input_dir[:-1]
    path_len = len(args.input_dir)

    for path, dirname, files in os.walk(args.input_dir):
        if path != args.input_dir:
            dest = os.path.join(args.output_dir, path[path_len + 1:])
            if not os.path.isdir(dest):
                os.mkdir(dest)
        else:
            dest = args.output_dir

        for f in files:
            if any(f.endswith(ext) for ext in ['jpg', 'jpeg', 'png']):
                filename = os.path.join(path, f)
                shutil.copy(filename, os.path.join(dest, f))
                img = cv2.imread(filename)
                rotate_img(img, args.out_image_width, args.out_image_height, dest, f)
                gen_canvas_img(img, args.out_image_width, args.out_image_height, dest, f, args.shift, args.zoom)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input_dir", type=str, required=True, help="Input dir of images")
    parser.add_argument("-o", "--output_dir", type=str, required=True, help="Output dir of images")
    parser.add_argument("-s", "--shift", type=int, default=8, help="Number of pixels to shift while augmentation")
    parser.add_argument("-z", "--zoom", type=int, default=10, help="zoom out start value")
    parser.add_argument("-cw", "--out_image_width", type=int, default=32, help="Width of images")
    parser.add_argument("-ch", "--out_image_height", type=int, default=32, help="Height of images")
    args = parser.parse_args()

    main(args)
