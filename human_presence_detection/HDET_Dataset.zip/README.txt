Open Images is a dataset of ~9 million URLs to images that have been annotated with labels spanning over 6000 categories. 
Lattice resized images and converted label data format to KITTI format. 
The original Open Images annotations are licensed by Google Inc. under CC BY 4.0 license. Our annotations are also licensed under CC BY 4.0.  
[[The contents of this repository are released under an Apache 2 license.]] 
THIS MAY OR MAY NOT BE RELEVANT DEPENDING ON WHETHER YOU�RE PROVIDING OTHER CODE AND IF SO THEN WE NEED TO PICK AN APPROPRIATE LICENSE.  
IF NOT RELEVANT, DELETE. The images are listed as having a CC BY 2.0 license.   
Note: while Google [[we]] tried to identify images that are licensed under a Creative Commons Attribution license, 
neither Google nor Lattice makes any representations or warranties regarding the license status of each image and you should verify the license for each image yourself.